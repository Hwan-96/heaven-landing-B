//section2 menu
let toggle = document.querySelector('.toggle');
let menu = document.querySelector('.menu');
toggle.onclick = function(){
  menu.classList.toggle('active')
}

//section2 menu
let toggleMo = document.querySelector('.mo-menu-toggle');
let menuMo = document.querySelector('#moMenu');
toggleMo.onclick = function(){
  menuMo.classList.toggle('active')
}